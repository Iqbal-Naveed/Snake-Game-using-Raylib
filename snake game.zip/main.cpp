#include <iostream>
#include <fstream>
#include <string>
#include "C:\raylib\raylib\src\raylib.h"
#include <raylib.h>

#include <deque>
#include <raymath.h>

using namespace std;

int cellSize = 20;
int cellCount = 25;
int offset = 75;
float interval;
double lastUpdateTime = 0;

bool ElementInDeque(Vector2 element, deque<Vector2> deque)
{
    for (unsigned int i = 0; i < deque.size(); i++)
    {
        if (Vector2Equals(deque[i], element))
        {
            return true;
        }
    }
    return false;
}

bool EventTriggered(double interval)
{
    double currentTime = GetTime();
    if (currentTime - lastUpdateTime >= interval)
    {
        lastUpdateTime = currentTime;
        return true;
    }
    return false;
}

class Game
{
public:
    bool running = true;
    int score = 0;

    virtual void Draw() = 0;
    virtual void Update() = 0;
    virtual void CheckCollisionWithFood() = 0;
    virtual void CheckCollisionWithEdges() = 0;
    virtual void GameOver() = 0;
    virtual void CheckCollisionWithTail() = 0;
};

class Snake : public Game
{
public:
    deque<Vector2> body = {Vector2{6, 9}, Vector2{5, 9}, Vector2{4, 9}};
    Vector2 direction = {1, 0};
    bool addSegment = false;

    void Draw()
    {
        for (unsigned int i = 0; i < body.size(); i++)
        {
            float x = body[i].x;
            float y = body[i].y;
            Rectangle segment = Rectangle{offset + x * cellSize, offset + y * cellSize, (float)cellSize, (float)cellSize};
            DrawRectangleRounded(segment, 0.5, 6, YELLOW);
        }
    }

    void Update()
    {
        body.push_front(Vector2Add(body[0], direction));
        if (addSegment == true)
        {
            addSegment = false;
        }
        else
        {
            body.pop_back();
        }
    }

    void Reset()
    {
        body = {Vector2{6, 9}, Vector2{5, 9}, Vector2{4, 9}};
        direction = {1, 0};
    }

    void CheckCollisionWithFood() {}

    void CheckCollisionWithEdges() {}

    void GameOver() {}

    void CheckCollisionWithTail() {}
};

class Food : public Game
{
public:
    Vector2 position;

    void Draw()
    {
        DrawRectangle((int)offset + position.x * cellSize, (int)offset + position.y * cellSize, (int)cellSize, (int)cellSize, RED);
    }

    Vector2 GenerateRandomCell()
    {
        float x = GetRandomValue(0, cellCount - 1);
        float y = GetRandomValue(0, cellCount - 1);
        return Vector2{x, y};
    }

    Vector2 GenerateRandomPos(deque<Vector2> snakeBody)
    {
        Vector2 position = GenerateRandomCell();
        while (ElementInDeque(position, snakeBody))
        {
            position = GenerateRandomCell();
        }
        return position;
    }

    void Update() {}

    void CheckCollisionWithFood() {}

    void CheckCollisionWithEdges() {}

    void GameOver() {}

    void CheckCollisionWithTail() {}
};

class SnakeGame : public Game
{
public:
    Snake snake;
    Food food;
    Sound eatSound;
    Sound wallSound;
    int highScore = 0;

    SnakeGame()
    {
        snake = Snake();
        food = Food();

        InitAudioDevice();
        eatSound = LoadSound("Sounds/eat.mp3");
        wallSound = LoadSound("Sounds/wall.mp3");
        generateRandomSnake();

        // Load high score from file
        ifstream file("highscore.txt");
        if (file.is_open())
        {
            string scoreStr;
            getline(file, scoreStr);
            highScore = stoi(scoreStr);
            file.close();
        }
    }

    void generateRandomSnake()
    {
        snake.body[0].x = (float)(GetRandomValue(5, cellCount - 1));
        snake.body[0].y = (float)(GetRandomValue(5, cellCount - 1));
        snake.body[1].x = snake.body[0].x - 1;
        snake.body[1].y = snake.body[0].y;
        snake.body[2].x = snake.body[0].x - 2;
        snake.body[2].y = snake.body[0].y;
    }

    ~SnakeGame()
    {
        UnloadSound(eatSound);
        UnloadSound(wallSound);
        CloseAudioDevice();
    }

    void Draw()
    {
        food.Draw();
        snake.Draw();
    }

    void Update()
    {
        if (running)
        {
            snake.Update();
            CheckCollisionWithFood();
            CheckCollisionWithEdges();
            CheckCollisionWithTail();
        }
    }

    void CheckCollisionWithFood()
    {
        if (Vector2Equals(snake.body[0], food.position))
        {
            food.position = food.GenerateRandomPos(snake.body);
            snake.addSegment = true;
            score++;
            PlaySound(eatSound);
            interval -= 0.01;

            if (score > highScore)
            {
                highScore = score;

                ofstream file("highscore.txt");
                if (file.is_open())
                {
                    file << highScore;
                    file.close();
                }
            }
        }
    }

    void CheckCollisionWithEdges()
    {
        if (snake.body[0].x == cellCount || snake.body[0].x == -1 || snake.body[0].y == cellCount || snake.body[0].y == -1)
        {
            GameOver();
            PlaySound(wallSound);
        }
    }

    void GameOver()
    {
        snake.Reset();
        food.position = food.GenerateRandomPos(snake.body);
        running = false;
        score = 0;
        interval = 0.22;
        generateRandomSnake();
    }

    void CheckCollisionWithTail()
    {
        deque<Vector2> headlessBody = snake.body;
        headlessBody.pop_front();
        if (ElementInDeque(snake.body[0], headlessBody))
        {
            GameOver();
            PlaySound(wallSound);
        }
    }
};

typedef struct Button
{
    Rectangle rect;
    Color color;
} Button;
Button button_start = {0};

bool button_start_clicked = false;

void initiate_button(Button *button, Rectangle rect, Color color)
{
    button->rect = rect;
    button->color = color;
}
bool is_mouse_over_button(Button button)
{
    return CheckCollisionPointRec(GetMousePosition(), button.rect);
}
static void Drawframe(void)
{
    if (is_mouse_over_button(button_start))
    {
        button_start.color = BLUE;
    }
    else
    {
        button_start.color = RED;
    }
    if (is_mouse_over_button(button_start) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        button_start_clicked = true;
    }
    BeginDrawing();

    ClearBackground(BLACK);

    DrawRectangleRec(button_start.rect, button_start.color);
    DrawText("Play", button_start.rect.x + button_start.rect.width / 2 - MeasureText("Play", 20) / 2, button_start.rect.y + button_start.rect.height / 2 - 20 / 2, 20, YELLOW);

    DrawFPS(10, 10);

    EndDrawing();
}

int main()
{
    int cellSize = 20;
    int cellCount = 25;
    int offset = 75;

    InitWindow(2 * offset + cellSize * cellCount, 2 * offset + cellSize * cellCount, "NSA Game(⌐■_■)");

    initiate_button(&button_start, (Rectangle){(int)(GetScreenWidth() / 2 - 100), (int)(GetScreenHeight() / 2 - 50), 200, 100}, RED);

    bool inMainMenu = true;

    while (!WindowShouldClose())
    {
        Drawframe();

        if (button_start_clicked)
        {
            inMainMenu = false;
            button_start_clicked = false;
        }

        if (!inMainMenu)
        {
            SnakeGame game = SnakeGame();
            interval = 0.18;

            while (WindowShouldClose() == false)
            {
                BeginDrawing();

                if (EventTriggered(interval))
                {
                    game.Update();
                }

                if ((IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_W)) && game.snake.direction.y != 1)
                {
                    game.snake.direction = {0, -1};
                    game.running = true;
                }
                if ((IsKeyPressed(KEY_DOWN) || IsKeyPressed(KEY_S)) && game.snake.direction.y != -1)
                {
                    game.snake.direction = {0, 1};
                    game.running = true;
                }
                if ((IsKeyPressed(KEY_LEFT) || IsKeyPressed(KEY_A)) && game.snake.direction.x != 1)
                {
                    game.snake.direction = {-1, 0};
                    game.running = true;
                }
                if ((IsKeyPressed(KEY_RIGHT) || IsKeyPressed(KEY_D)) && game.snake.direction.x != -1)
                {
                    game.snake.direction = {1, 0};
                    game.running = true;
                }

                // Drawing
                ClearBackground(BLACK);
                DrawRectangleLinesEx(Rectangle{(float)offset - 5, (float)offset - 5, (float)cellSize * cellCount + 10, (float)cellSize * cellCount + 10}, 5, YELLOW);
                DrawText("DSA Snake", offset - 8, 20, 30, YELLOW);
                DrawText(TextFormat("SCORE = %i", game.score), offset - 5, offset + cellSize * cellCount + 10, 15, YELLOW);
                DrawText(("HIGHSCORE = " + to_string(game.highScore)).c_str(), offset - 5, offset - 5 + cellSize * cellCount + 40, 15, ORANGE);
                game.Draw();

                EndDrawing();
            }
            CloseWindow();
        }
    }

    return 0;
}